#include "mem_manage.hpp"

IMemoryManager::~IMemoryManager() {}
